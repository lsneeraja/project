# House Sales in King county,WA
This dataset contains house sale prices for King County, which includes Seattle. It includes homes sold between May 2014 and May 2015.
Goal is to explore the key influencers which cause House sales price to increase as well as to predict House sales price in 2016 based on the variables available in the dataset.


```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
%matplotlib inline
import statsmodels.api as sm
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn import metrics
from scipy import stats
from scipy.stats import norm, skew
from sklearn.ensemble import RandomForestRegressor
```

## Reading the Data

##  Feature Description
ID : Unique ID of each house sold
Date : Date of House sale
Price : Price of each sold house
Bedrooms : Number of bedrooms
Bathrooms : Number of bathrooms
Sqft_living : Square footage of interior living space
Sqft_lot : Square footage of land space
Floors : Number of floors
Waterfront : Variable that indicates whether the house overlooks waterfront or not
View : An index from 0 to 4 of how good the view of the property is
Condition : An index from 1 to 5 on the condition of the house
Grade : An index from 1 to 13, where
        1-3 falls short of building construction and design
        7 has an avergae quality of construction and design
        11-13 have higher quality of construction and design
Sqft_above : Square footage of interior housing space that is above ground level
Sqft_basement : Square footage of interior housing space that is below ground level
Yr_built : Year house was built
Yr_renovated : Year house was renovated
Zipcode : Zipcode area the house is in
Lat : Lattitude
Long : Longitude
Sqft_living15 :Square footage of interior living space for nearest 15 neighbours
Sqft_lot15 :Square footage of land space for nearest 15 neighbours


```python
df = pd.read_csv(r'C:\Users\lsnee\OneDrive\Desktop\House data.csv')
print(df.shape)
print(df.info())
```

    (21613, 21)
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 21613 entries, 0 to 21612
    Data columns (total 21 columns):
    id               21613 non-null int64
    date             21613 non-null object
    price            21613 non-null float64
    bedrooms         21613 non-null int64
    bathrooms        21613 non-null float64
    sqft_living      21613 non-null int64
    sqft_lot         21613 non-null int64
    floors           21613 non-null float64
    waterfront       21613 non-null int64
    view             21613 non-null int64
    condition        21613 non-null int64
    grade            21613 non-null int64
    sqft_above       21613 non-null int64
    sqft_basement    21613 non-null int64
    yr_built         21613 non-null int64
    yr_renovated     21613 non-null int64
    zipcode          21613 non-null int64
    lat              21613 non-null float64
    long             21613 non-null float64
    sqft_living15    21613 non-null int64
    sqft_lot15       21613 non-null int64
    dtypes: float64(5), int64(15), object(1)
    memory usage: 3.5+ MB
    None
    

## Descriptive Statistics of Dataset


```python
print(df.describe())
```

                     id         price      bedrooms     bathrooms   sqft_living  \
    count  2.161300e+04  2.161300e+04  21613.000000  21613.000000  21613.000000   
    mean   4.580302e+09  5.401822e+05      3.370842      2.114757   2079.899736   
    std    2.876566e+09  3.673622e+05      0.930062      0.770163    918.440897   
    min    1.000102e+06  7.500000e+04      0.000000      0.000000    290.000000   
    25%    2.123049e+09  3.219500e+05      3.000000      1.750000   1427.000000   
    50%    3.904930e+09  4.500000e+05      3.000000      2.250000   1910.000000   
    75%    7.308900e+09  6.450000e+05      4.000000      2.500000   2550.000000   
    max    9.900000e+09  7.700000e+06     33.000000      8.000000  13540.000000   
    
               sqft_lot        floors    waterfront          view     condition  \
    count  2.161300e+04  21613.000000  21613.000000  21613.000000  21613.000000   
    mean   1.510697e+04      1.494309      0.007542      0.234303      3.409430   
    std    4.142051e+04      0.539989      0.086517      0.766318      0.650743   
    min    5.200000e+02      1.000000      0.000000      0.000000      1.000000   
    25%    5.040000e+03      1.000000      0.000000      0.000000      3.000000   
    50%    7.618000e+03      1.500000      0.000000      0.000000      3.000000   
    75%    1.068800e+04      2.000000      0.000000      0.000000      4.000000   
    max    1.651359e+06      3.500000      1.000000      4.000000      5.000000   
    
                  grade    sqft_above  sqft_basement      yr_built  yr_renovated  \
    count  21613.000000  21613.000000   21613.000000  21613.000000  21613.000000   
    mean       7.656873   1788.390691     291.509045   1971.005136     84.402258   
    std        1.175459    828.090978     442.575043     29.373411    401.679240   
    min        1.000000    290.000000       0.000000   1900.000000      0.000000   
    25%        7.000000   1190.000000       0.000000   1951.000000      0.000000   
    50%        7.000000   1560.000000       0.000000   1975.000000      0.000000   
    75%        8.000000   2210.000000     560.000000   1997.000000      0.000000   
    max       13.000000   9410.000000    4820.000000   2015.000000   2015.000000   
    
                zipcode           lat          long  sqft_living15     sqft_lot15  
    count  21613.000000  21613.000000  21613.000000   21613.000000   21613.000000  
    mean   98077.939805     47.560053   -122.213896    1986.552492   12768.455652  
    std       53.505026      0.138564      0.140828     685.391304   27304.179631  
    min    98001.000000     47.155900   -122.519000     399.000000     651.000000  
    25%    98033.000000     47.471000   -122.328000    1490.000000    5100.000000  
    50%    98065.000000     47.571800   -122.230000    1840.000000    7620.000000  
    75%    98118.000000     47.678000   -122.125000    2360.000000   10083.000000  
    max    98199.000000     47.777600   -121.315000    6210.000000  871200.000000  
    

## Are there any NULL values 


```python
print(df.isnull().any())
```

    id               False
    date             False
    price            False
    bedrooms         False
    bathrooms        False
    sqft_living      False
    sqft_lot         False
    floors           False
    waterfront       False
    view             False
    condition        False
    grade            False
    sqft_above       False
    sqft_basement    False
    yr_built         False
    yr_renovated     False
    zipcode          False
    lat              False
    long             False
    sqft_living15    False
    sqft_lot15       False
    dtype: bool
    

## Correlation between various features


```python
corr = df.corr()
plt.figure(figsize=(25,10))
Heatmap = sns.heatmap(corr,annot=True,linewidths=0.25,vmax=1.0, square=True, cmap="Greens", linecolor='k')
```


![png](output_10_0.png)


* Price has high positive correlation with Sqft_living and moderate positive correlation with Bathrooms,Sqft_above,View,Grade and Sqft_living15
* Price has low positive correlation with Bedrooms,floors,Sqft_basement and Yr_renovated
* Price has non significant relationship with Sqft_lot,Year,Zipcode and Sqft_lot15

## Converting Date format


```python
import datetime
df['date']=pd.to_datetime(df['date'])
df = df.sort_values(by='date')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date</th>
      <th>price</th>
      <th>bedrooms</th>
      <th>bathrooms</th>
      <th>sqft_living</th>
      <th>sqft_lot</th>
      <th>floors</th>
      <th>waterfront</th>
      <th>view</th>
      <th>condition</th>
      <th>grade</th>
      <th>sqft_above</th>
      <th>sqft_basement</th>
      <th>yr_built</th>
      <th>yr_renovated</th>
      <th>lat</th>
      <th>sqft_living15</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>16768</td>
      <td>2014-05-02</td>
      <td>437500.0</td>
      <td>3</td>
      <td>2.25</td>
      <td>1970</td>
      <td>35100</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>9</td>
      <td>1970</td>
      <td>0</td>
      <td>1977</td>
      <td>0</td>
      <td>47.4635</td>
      <td>2340</td>
    </tr>
    <tr>
      <td>9596</td>
      <td>2014-05-02</td>
      <td>790000.0</td>
      <td>3</td>
      <td>2.50</td>
      <td>2600</td>
      <td>4750</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>9</td>
      <td>1700</td>
      <td>900</td>
      <td>1951</td>
      <td>0</td>
      <td>47.6833</td>
      <td>2380</td>
    </tr>
    <tr>
      <td>9587</td>
      <td>2014-05-02</td>
      <td>675000.0</td>
      <td>5</td>
      <td>2.50</td>
      <td>2820</td>
      <td>67518</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>8</td>
      <td>2820</td>
      <td>0</td>
      <td>1979</td>
      <td>0</td>
      <td>47.5794</td>
      <td>2820</td>
    </tr>
    <tr>
      <td>20602</td>
      <td>2014-05-02</td>
      <td>555000.0</td>
      <td>4</td>
      <td>2.50</td>
      <td>3310</td>
      <td>6500</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>8</td>
      <td>3310</td>
      <td>0</td>
      <td>2012</td>
      <td>0</td>
      <td>47.5150</td>
      <td>2380</td>
    </tr>
    <tr>
      <td>11577</td>
      <td>2014-05-02</td>
      <td>440000.0</td>
      <td>4</td>
      <td>2.25</td>
      <td>2160</td>
      <td>8119</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>8</td>
      <td>1080</td>
      <td>1080</td>
      <td>1966</td>
      <td>0</td>
      <td>47.5443</td>
      <td>1850</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>7898</td>
      <td>2015-05-14</td>
      <td>183000.0</td>
      <td>3</td>
      <td>1.00</td>
      <td>1170</td>
      <td>7320</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>7</td>
      <td>1170</td>
      <td>0</td>
      <td>1962</td>
      <td>0</td>
      <td>47.4685</td>
      <td>2040</td>
    </tr>
    <tr>
      <td>928</td>
      <td>2015-05-14</td>
      <td>359000.0</td>
      <td>2</td>
      <td>2.75</td>
      <td>1370</td>
      <td>1140</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>8</td>
      <td>1080</td>
      <td>290</td>
      <td>2009</td>
      <td>0</td>
      <td>47.7052</td>
      <td>1370</td>
    </tr>
    <tr>
      <td>5637</td>
      <td>2015-05-15</td>
      <td>450000.0</td>
      <td>5</td>
      <td>2.00</td>
      <td>1870</td>
      <td>7344</td>
      <td>1.5</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>7</td>
      <td>1870</td>
      <td>0</td>
      <td>1960</td>
      <td>0</td>
      <td>47.5951</td>
      <td>1870</td>
    </tr>
    <tr>
      <td>13053</td>
      <td>2015-05-24</td>
      <td>445500.0</td>
      <td>2</td>
      <td>1.75</td>
      <td>1390</td>
      <td>6670</td>
      <td>1.0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>6</td>
      <td>720</td>
      <td>670</td>
      <td>1941</td>
      <td>0</td>
      <td>47.6914</td>
      <td>920</td>
    </tr>
    <tr>
      <td>16594</td>
      <td>2015-05-27</td>
      <td>1310000.0</td>
      <td>4</td>
      <td>2.25</td>
      <td>3750</td>
      <td>5000</td>
      <td>2.0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>8</td>
      <td>2440</td>
      <td>1310</td>
      <td>1924</td>
      <td>0</td>
      <td>47.6747</td>
      <td>2170</td>
    </tr>
  </tbody>
</table>
<p>21613 rows × 17 columns</p>
</div>



## Skewness of Data


```python
sns.distplot(df.skew(),color='blue',axlabel ='Skewness')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26fe39896c8>




![png](output_15_1.png)


## Count of Bedrooms

There is one house with 33 bedrooms which is very unique for any house


```python
print(df['bedrooms'].value_counts())
sns.countplot(df.bedrooms, order = df['bedrooms'].value_counts().index)
```

    3     9824
    4     6882
    2     2760
    5     1601
    6      272
    1      199
    7       38
    8       13
    0       13
    9        6
    10       3
    11       1
    33       1
    Name: bedrooms, dtype: int64
    




    <matplotlib.axes._subplots.AxesSubplot at 0x2750cb8b888>




![png](output_18_2.png)


## Count of Unique Year built values


```python
print(df['yr_built'].value_counts().unique())
plt.figure(figsize=(16,9))
sns.countplot(df.yr_built, order = df['yr_built'].value_counts().index)
plt.tick_params(axis='x',which='major',labelsize=12)
plt.xticks(x='yr_built',rotation=90)
plt.tight_layout()
```

    [559 454 450 433 422 417 387 381 367 350 343 334 320 312 305 294 290 280
     271 270 265 263 256 253 250 249 248 240 239 235 230 229 228 224 223 222
     220 218 215 212 202 201 199 198 195 189 187 180 177 172 170 169 165 162
     161 156 149 143 140 139 134 132 130 126 120 115 114 106 105 104  98  95
      94  92  90  88  87  86  84  79  76  74  73  68  65  64  61  59  56  54
      52  46  45  40  38  30  29  27  24  21]
    


![png](output_20_1.png)


## Count of bathrooms

There are 10 houses with 0 bathrooms


```python
print(df['bathrooms'].value_counts())
sns.countplot(df.bathrooms, order = df['bathrooms'].value_counts().index)
plt.tick_params(axis='x',which='major',labelsize=10)
plt.xticks(x='bathrooms',rotation=90)
plt.tight_layout()
```

    2.50    5380
    1.00    3852
    1.75    3048
    2.25    2047
    2.00    1930
    1.50    1446
    2.75    1185
    3.00     753
    3.50     731
    3.25     589
    3.75     155
    4.00     136
    4.50     100
    4.25      79
    0.75      72
    4.75      23
    5.00      21
    5.25      13
    0.00      10
    5.50      10
    1.25       9
    6.00       6
    0.50       4
    5.75       4
    8.00       2
    6.25       2
    6.50       2
    6.75       2
    7.50       1
    7.75       1
    Name: bathrooms, dtype: int64
    


![png](output_23_1.png)


## Count of Floors


```python
print(df['floors'].value_counts())
sns.countplot(df.floors, order = df['floors'].value_counts().index)
plt.tick_params(axis='x',which='major',labelsize=10)
plt.xticks(x='floors',rotation=90)
plt.tight_layout()
```

    1.0    10680
    2.0     8241
    1.5     1910
    3.0      613
    2.5      161
    3.5        8
    Name: floors, dtype: int64
    


![png](output_25_1.png)


## Count of Grade


```python
print(df['grade'].value_counts())
sns.countplot(df.grade, order = df['grade'].value_counts().index)
plt.tick_params(axis='x',which='major',labelsize=10)
plt.xticks(x='grade',rotation=90)
plt.tight_layout()
```

    7     8981
    8     6068
    9     2615
    6     2038
    10    1134
    11     399
    5      242
    12      90
    4       29
    13      13
    3        3
    1        1
    Name: grade, dtype: int64
    


![png](output_27_1.png)


## Scatter plot of Independent Variables


```python
sns.scatterplot(df.price,df.bedrooms)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26fe4893e48>




![png](output_29_1.png)



```python
sns.scatterplot(df.price,df.bathrooms)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26fe3e1e688>




![png](output_30_1.png)



```python
sns.scatterplot(df.price,df.sqft_living)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26fe3f2ac48>




![png](output_31_1.png)



```python
sns.scatterplot(df.price,df.sqft_lot)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26fe4014808>




![png](output_32_1.png)



```python
sns.scatterplot(df.price,df.floors)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26fe42d2308>




![png](output_33_1.png)



```python
sns.scatterplot(df.price,df.yr_built)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x26fe434b148>




![png](output_34_1.png)


## Removing Outliers from 'Bedrooms' column


```python
q1 = df['bedrooms'].quantile(0.25)
q3 = df['bedrooms'].quantile(0.75)
IQR = q3-q1
IQR
Lower_Fence = q1 - (1.5 * IQR)
Upper_Fence = q3 + (1.5 * IQR)
df = df[(df['bedrooms']>=Lower_Fence)&(df['bedrooms']<=Upper_Fence)]
df.shape
```




    (21067, 21)



## Removing Outlier from 'bathrooms' column


```python
q1 = df['bathrooms'].quantile(0.25)
q3 = df['bathrooms'].quantile(0.75)
IQR = q3-q1
IQR
Lower_Fence = q1 - (1.5 * IQR)
Upper_Fence = q3 + (1.5 * IQR)
df = df[(df['bathrooms']>=Lower_Fence)&(df['bathrooms']<=Upper_Fence)]
df.shape
```




    (20606, 21)



## Removing Outliers from Grade


```python
q1 = df['grade'].quantile(0.25)
q3 = df['grade'].quantile(0.75)
IQR = q3-q1
IQR
Lower_Fence = q1 - (1.5 * IQR)
Upper_Fence = q3 + (1.5 * IQR)
df = df[(df['grade']>=Lower_Fence)&(df['grade']<=Upper_Fence)]
df.shape
```




    (19137, 21)



## Removing Outliers from sqft_lot


```python
q1 = df['sqft_lot'].quantile(0.25)
q3 = df['sqft_lot'].quantile(0.75)
IQR = q3-q1
IQR
Lower_Fence = q1 - (1.5 * IQR)
Upper_Fence = q3 + (1.5 * IQR)
df = df[(df['sqft_lot']>=Lower_Fence)&(df['sqft_lot']<=Upper_Fence)]
df.shape
```




    (17199, 21)



## Removing Outliers from sqft_living


```python
q1 = df['sqft_living'].quantile(0.25)
q3 = df['sqft_living'].quantile(0.75)
IQR = q3-q1
IQR
Lower_Fence = q1 - (1.5 * IQR)
Upper_Fence = q3 + (1.5 * IQR)
df = df[(df['sqft_living']>=Lower_Fence)&(df['sqft_living']<=Upper_Fence)]
df.shape
```




    (17007, 21)



## Removing Outliers from sqft_above


```python
q1 = df['sqft_above'].quantile(0.25)
q3 = df['sqft_above'].quantile(0.75)
IQR = q3-q1
IQR
Lower_Fence = q1 - (1.5 * IQR)
Upper_Fence = q3 + (1.5 * IQR)
df = df[(df['sqft_above']>=Lower_Fence)&(df['sqft_above']<=Upper_Fence)]
df.shape
```




    (16626, 21)



## Removing Outliers sqft_living15


```python
q1 = df['sqft_living15'].quantile(0.25)
q3 = df['sqft_living15'].quantile(0.75)
IQR = q3-q1
IQR
Lower_Fence = q1 - (1.5 * IQR)
Upper_Fence = q3 + (1.5 * IQR)
df = df[(df['sqft_living15']>=Lower_Fence)&(df['sqft_living15']<=Upper_Fence)]
df.shape
```




    (16446, 21)



## Defining Dependent and Independent Variables

After analyzing the correlation between various variables and Price,variables that have significant linear relationship with Price were chosen as predictor variables.


```python
col = ['bedrooms','bathrooms','sqft_living','sqft_lot','floors','grade','view','sqft_above','yr_built','yr_renovated','sqft_living15','sqft_basement','waterfront']
X = df[col]
Y = df['price']
print(X.shape)
print(Y.shape)
```

    (21613, 13)
    (21613,)
    

## Divide the data into train and test sets


```python
X_train, X_test, Y_train, Y_test = train_test_split(X,Y,test_size=0.2, random_state=100)
```

## Glance at the shape of the train and test sets


```python
print(X_train.shape)
print(X_test.shape)
print(Y_train.shape)
print(Y_test.shape)
```

    (17290, 13)
    (4323, 13)
    (17290,)
    (4323,)
    

# Random Forest Regression : Fit the train sets into the model


```python
rf = RandomForestRegressor(n_estimators=100)
model_rf = rf.fit(X_train,Y_train)
```

## Predict Test variable


```python
y_rf_pred = model_rf.predict(X_test)
output= pd.DataFrame({"Actual":Y_test, "Predicted" : y_rf_pred})
output
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>19836</td>
      <td>285000.0</td>
      <td>441554.000000</td>
    </tr>
    <tr>
      <td>10442</td>
      <td>239950.0</td>
      <td>334558.013333</td>
    </tr>
    <tr>
      <td>20548</td>
      <td>460000.0</td>
      <td>540463.830000</td>
    </tr>
    <tr>
      <td>11014</td>
      <td>397500.0</td>
      <td>538126.450000</td>
    </tr>
    <tr>
      <td>4138</td>
      <td>545000.0</td>
      <td>551559.080000</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>5625</td>
      <td>235000.0</td>
      <td>242560.260000</td>
    </tr>
    <tr>
      <td>8698</td>
      <td>500000.0</td>
      <td>530676.560000</td>
    </tr>
    <tr>
      <td>9786</td>
      <td>850000.0</td>
      <td>689346.700000</td>
    </tr>
    <tr>
      <td>2784</td>
      <td>340000.0</td>
      <td>502545.900000</td>
    </tr>
    <tr>
      <td>9552</td>
      <td>788000.0</td>
      <td>657288.270000</td>
    </tr>
  </tbody>
</table>
<p>4323 rows × 2 columns</p>
</div>



## Metrics of the Model


```python
def mean_absolute_percentage_error(Y_test,y_rf_pred):
    Y_test, Y_pred = np.array(Y_test), np.array(y_rf_pred)
    return np.mean(np.abs((Y_test - y_rf_pred) / Y_test)) * 100
print('Mean Absolute Percentage Error(MAPE) : ', mean_absolute_percentage_error(Y_test,y_rf_pred))
```

    Mean Absolute Percentage Error(MAPE) :  23.610455953860978
    


```python
print('Mean Absolute Error : ', metrics.mean_absolute_error(Y_test,y_rf_pred))
print('Root Mean Squared Error : ', np.sqrt(metrics.mean_squared_error(Y_test,y_rf_pred)))
print('R Squared Value of the Model : ', metrics.r2_score(Y_test,y_rf_pred))
```

    Mean Absolute Error :  116561.97252675978
    Root Mean Squared Error :  183517.4249388906
    R Squared Value of the Model :  0.7504356128071856
    

## Plotting the results


```python
plt.xlabel("y_test")
plt.ylabel("predicted values")
sns.regplot(Y_test,y_rf_pred)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x20b101ad0c8>




![png](output_64_1.png)


# Simple Linear Regression


```python
regressor = LinearRegression()
regressor.fit(X_train,Y_train)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=False)



## Coefficients of the model


```python
print(regressor.intercept_)
print(regressor.coef_)
```

    6861857.371179586
    [-3.70930131e+04  5.39282723e+04  1.05283408e+02 -2.34376531e-01
      2.59860987e+04  1.21697932e+05  4.18506015e+04  4.97023584e+01
     -3.88632350e+03 -6.32738440e+00  2.21348389e+01  5.55810500e+01
      5.88973238e+05]
    

## Prediction


```python
Y_pred = regressor.predict(X_test)
Y_pred = pd.DataFrame(Y_pred, columns=['Predicted'])
Y_test = pd.DataFrame(Y_test,columns=['Actual'])
print(Y_pred,Y_test)
```

              Predicted
    0     404299.338087
    1     391730.544994
    2     630161.046458
    3     408239.896657
    4     484850.425661
    ...             ...
    4318  284230.968251
    4319  526069.731510
    4320  698272.458526
    4321  573630.213148
    4322  683116.227948
    
    [4323 rows x 1 columns] Empty DataFrame
    Columns: [Actual]
    Index: []
    

* Predicting Selling Prices :
Now that we have created the model, we can plug in the values of various variables and predict the House price.
For example :
Consider a House with
Bedrooms = 2
Bathrooms = 2
Square footage of living space = 2500 sqft
Square footage of the house lot = 5000 sqft
Number of floors = 2
Grade of the house = 7
Noumber of views = 0
Sqft_above = 2170 sqft
Year house was built = 2005
Year house was renovated = 0 (ie NO renovation)
Sqft_living15 = 2500 sqft
Sqft_basement = 0 (ie NO basement)
Waterfront = 0
Let's see what will be the House price based on above features


```python
col = ['bedrooms','bathrooms','sqft_living','sqft_lot','floors','grade','view','sqft_above','yr_built','yr_renovated','sqft_living15','sqft_basement','waterfront']
Feature_input = [[2,2,2500,5000,2,7,0,2170,2005,0,2500,0,0]]
for i,price in enumerate(regressor.predict(Feature_input)):
        print("Predicted selling price for Client's home: ${:,.2f}".format(price))
```

    Predicted selling price for Client's home: $432,534.85
    

Tableau Visualization : https://public.tableau.com/profile/neerajals#!/vizhome/Capstone2_15816359523670/Story1
